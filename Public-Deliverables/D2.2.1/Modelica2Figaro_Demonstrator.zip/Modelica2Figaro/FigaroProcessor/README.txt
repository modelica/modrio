This directory contains the Figaro processor (property of EDF) and test examples showing how to use it in order to generate fault trees from Figaro language descriptions. 

To test the Fault tree generation, double click on 
Gentree.bat in the test directories

The file gentree.bat shows what command must be launched. 
The execution will create the following files in the test directory:
  - FaultTree.xml : the fault tree
  - process.log : trace of operations performed 
  - result.xml : warnings, summary of operations
  - tmpfig0.fi : the instanciation of the model in Figaro O
  - tmpfig0.rir : a binary compiled version of the previous file
  - tmpfigar.xml : the fault tree + options that were specified in the command xml file


The C program needed to call the Figaro processor from Modelica is in the file : st.c 
(it is not needed to run the above tests)