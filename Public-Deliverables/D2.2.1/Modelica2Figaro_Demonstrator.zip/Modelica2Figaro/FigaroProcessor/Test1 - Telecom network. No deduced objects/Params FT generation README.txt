This file contains French keywords

Unfortunately, the program won't work with English keywords.
Here are the possible options


<GEN_TREE_OPTIONS>
		<SIMPLIFICATION>AUCUNE|PARTIELLE|TOTALE</SIMPLIFICATION>
		<COHERENCY>AUCUNE|PARTIELLE|TOTALE</COHERENCY>
		<UNLOOP>FAUX|VRAI</UNLOOP>
		<TREE_NAME>name of the generated fault tree</TREE_NAME>
		<PREFIX>__ARBRE__</PREFIX>
		<TEST_VARIABLE>
			<OBJECT>name of the object containing the variable to be "explained" by the FT</OBJECT>
			<VARIABLE>Name of the variable to be explained</VARIABLE>
		</TEST_VARIABLE>
		<MAX_SONS_GATE>100</MAX_SONS_GATE>
		<LIST_GROUPS>
			<GROUP>Group1</GROUP>
			<GROUP>SANS_NOM</GROUP>
		</LIST_GROUPS>
		<COMMENT>RO</COMMENT>
</GEN_TREE_OPTIONS>

Meaning

    <SIMPLIFICATION>AUCUNE|PARTIELLE|TOTALE</SIMPLIFICATION>
      AUCUNE : negations are kept in the FT, wherever they appear
      PARTIELLE : negations are "pushed" to the leaves, using the De Morgan Boolean laws
      TOTALE = PARTIELLE + negations of failure leaves are considered always true 
          ensures that the generated FT is "coherent"

    <UNLOOP>FAUX|VRAI</UNLOOP>
       FAUX : the sons of an event can contain that event
       VRAI : the situation above is avoided, but this may create a very large FT
	   
	<LIST_GROUPS>
		This structure contains the list of rules groups that must be taken into account 
		for the FT generation. The group "SANS_NOM" represents the rules for which no 
		group was assigned. 