This file contains commands for the Figaro processor
For this knowledge base, deduced objects are used. The algorithm specifying how to 
create them from the objects input by the user is in the file library.bdc. 
The only thing to do in order to take deduced objects into account is to add the 
line        <FILE>.\Library.bdc</FILE> in this file. 


    <LOAD_BDC_FI>
        <FILE_FI>.\Library.fi</FILE_FI>
        <FILE>.\Library.bdc</FILE>
    </LOAD_BDC_FI> 
