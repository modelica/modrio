#include <string.h>
#include "ModelicaUtilities.h"
// Launches the command figp.exe -testxml xmlfilename
// There must not be any blank in the path of figp
void st(String* figp_path, String* xml)
{
    String* cmd="start";
	ModelicaFormatMessage("figp_path=%s\n",figp_path);
	ModelicaFormatMessage("xml=%s\n",xml);
	strcat(cmd," ");
	strcat(cmd,figp_path);
	strcat(cmd,"/figp.exe");
	strcat(cmd," ");
	strcat(cmd,"-testxml");
	strcat(cmd," ");
	strcat(cmd,xml);
	system(cmd);
}