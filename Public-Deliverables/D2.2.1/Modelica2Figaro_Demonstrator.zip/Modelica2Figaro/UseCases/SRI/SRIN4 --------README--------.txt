The file: 
SRIN4_OpenProd_WithoutPropertiesTotal.mo 
	can only be loaded in Dymola: it contains a version of SRI which is suitable for simulation. 

SRIN4_v3 UTF8 with Figaro additions.mo
	can be loaded both in Dymola and in OpenModelica. Its model "SRI_v3" contains Figaro complements in string parameters, that allow, both with Dymola and OpenModelica, to produce a complete Figaro0 model and a fault tree, thanks to the Figaro processor.
	The error message about the version of library ThermosysPro used by the system model can be ignored. 
	This model cannot be simulated.  