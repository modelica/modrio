This directory contains:

 - jEdit4.5VisualFigaro.zip: tools for editing Figaro librairies (version 2.0b). See installation instructions
    in DocFigaroTools directory. Note that the OpenModelica installer also installs 
	Visual Figaro in the following directory: OpenModelica_install_dir/share/jEdit4.5_Visual_Figaro/
	The file jEdit4.5VisualFigaro.zip is given here as a stand alone Figaro package. 

 - Sample knowledge bases for KB3: examples in English and French, including the 3 knowledge bases necessary 
   for the tutorial  