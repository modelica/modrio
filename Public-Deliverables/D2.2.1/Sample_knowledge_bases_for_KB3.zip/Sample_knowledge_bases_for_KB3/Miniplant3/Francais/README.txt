Miniplant3 est le corrig� de la 3�me et derni�re �tape de la formation � l'�criture 
de bases de connaissances. Cette base de connaissances est comment�e dans l'article joint
sur MINIPLANT et la simulation de Monte Carlo. 