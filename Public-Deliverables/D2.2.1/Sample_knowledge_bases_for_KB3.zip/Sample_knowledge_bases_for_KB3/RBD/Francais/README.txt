Modif du 7 d�cembre 2006 : 
MODIFICATION DE LA BDC RBD XML
1.	Groupes de r�gles non modifiables pour les mod�les de g�n�ration ADD et de simulation
2.	Ajout de traitements externes
a.	FIGSEQ
b.	YAMS
3.	Visualisation des portes k/n : Ajout de la valeur de k en plus de la notion de � reli� �
4.	Diminution de la taille de l�ic�ne des portes k/n
5.	Suppression des r�gles de remplissage d�interfaces inutiles
MODIFICATION DE LA BDC RBD FIGARO
1.	Ajout de la facette EDITION NOT MODIFIABLE pour l�interface � blocks_to_replace � 
        des blocs secours
2.	Suppression des contournements de bugs mis en place en 2003

ATTENTION : 
R�cup�ration des �tudes : quand des ADD ont �t� g�n�r�s avec la pr�c�dente version de la BDC, on a perdu 
le groupe associ� � la g�n�ration d�arbre dans le param�trage � quand on r�g�n�re un ADD � partir 
des ADD existants, il faut choisir � nouveau le groupe sinon on obtient un arbre vide�
Le mieux est de r�g�n�rer les ADD en partant du mod�le BDC.
--------------------------------------------------------------------------------------------------------
Modif du 4 juillet 2005 : Remplacement du bdceng.xsd par un plus r�cent, avec tous tags en anglais. 
Correction d'un bug : l'interface blocks_to_replace n'�tait pas remplie car l'instruction de 
remplissage n'�tait �crite que pour une des extr�mit�s du lien de secours.
--------------------------------------------------------------------------------------------------------
Modif du 6 oct 2004 : suppression dans le.bdc du champ date_modification, et ajout
du champ description contenant cette date. Ainsi on peut voir dans une BDD quelle version 
on utilise.
--------------------------------------------------------------------------------------------------------
Modifs du 29 avril 2004 : r�tablissement des accents, choix des bons groupes suivant
  traitement (suppression de l'objet syst�me "options").
--------------------------------------------------------------------------------------------------------
Modifs du 30 avril 2003 : correction de bugs mineurs ds le .bdc, d�tect�s par
la derni�re version de KB3. Compatible avec versions pr�c�dentes.