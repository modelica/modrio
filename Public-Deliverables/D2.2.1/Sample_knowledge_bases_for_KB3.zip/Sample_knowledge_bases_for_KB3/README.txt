﻿The directory "Sample knowledge bases for KB3" contains several ready to use simple knowledge bases both in French and in English.
Some of the KB have been translated automatically: in that case, the KB directory contains
the two sub-directories Francais and English.
The database "Kit pedagogique (educational kit) vX.Y.mdb" can be readily loaded in KB3 by the menu "File/Open database": it contains all the 
knowledge bases and examples of small systems input with those knowledge bases.


Le répertoire "Sample knowledge bases for KB3" contient plusieurs bases de connaissances simples
et prêtes à l'emploi, en Français et en Anglais. 
Certaines bases de connaissances ont été traduites automatiquement: dans ce cas, 
le répertoire de la base contient les deux sous-répertoires Francais et English.
La base de données "Kit pedagogique (educational kit) vX.Y.mdb" peut être directement chargée dans KB3 par le menu "Fichier/Ouvrir base de données" :
elle contient toutes les bases de connaissances et des exemples de petits systèmes saisis avec ces bases de connaissances.