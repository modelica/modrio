The deliverable report is in D513_ModelicaXMLFormat.pdf.
The ModelicaXML folder contains the XML schemas, and is a checkout of

https://github.com/modelica-association/ModelicaXML,

of the version that was current at the time of the deliverable's writing, i.e.

https://github.com/modelica-association/ModelicaXML/commit/df5fbc41577e5c259d62fa9b5e44129f9bb24ae5


The deliverable D5.1.3 is public (PU)
